let currentSlide = 1;
const totalSlides = 8;
let candlesBlown = false;
let audioContext;
let analyser;
let microphone;
let micStream;
let bgMusicWasActive = false;

function getAudioElements() {
  return {
    bgMusic: document.getElementById("bg-music"),
    voiceNote: document.getElementById("voice-note"),
    voiceBtn: document.getElementById("voice-play-btn")
  };
}

function initDots() {
  const dotsContainer = document.getElementById("dots-container");
  if (!dotsContainer) return;
  dotsContainer.innerHTML = "";
  for (let i = 1; i <= totalSlides; i++) {
    const dot = document.createElement("div");
    dot.className = "dot" + (i === 1 ? " active-dot" : "");
    dotsContainer.appendChild(dot);
  }
}

function updateDots() {
  const dots = document.querySelectorAll(".dot");
  dots.forEach((dot, index) => {
    dot.classList.toggle("active-dot", index + 1 === currentSlide);
  });
}

function updateNavButtons() {
  const prevBtn = document.getElementById("btn-prev");
  const nextBtn = document.getElementById("btn-next");

  if (prevBtn) {
    prevBtn.style.visibility = currentSlide === 1 ? "hidden" : "visible";
  }

  if (nextBtn) {
    if (currentSlide === 3 && !candlesBlown) {
      nextBtn.style.visibility = "hidden";
      nextBtn.style.pointerEvents = "none";
    } else {
      nextBtn.style.visibility = "visible";
      nextBtn.style.pointerEvents = "auto";
    }
  }
}

function showSlide(index) {
  if (currentSlide === 3 && index > 3 && !candlesBlown) {
    const micStatus = document.getElementById("mic-status");
    if (micStatus) {
      micStatus.innerText = "⚠️ Please blow out the candles with your mic first!";
    }
    return;
  }

  const { bgMusic, voiceNote, voiceBtn } = getAudioElements();

  if (currentSlide === 7 && index !== 7 && voiceNote && !voiceNote.paused) {
    voiceNote.pause();
    voiceNote.currentTime = 0;
    if (voiceBtn) voiceBtn.textContent = "▶ Play Voice Note";
    resumeBgMusic();
  }

  document.querySelectorAll(".slide").forEach((slide) => {
    slide.classList.remove("active-slide");
  });

  const activeSlide = document.getElementById(`slide-${index}`);
  if (activeSlide) activeSlide.classList.add("active-slide");

  currentSlide = index;
  updateDots();
  updateNavButtons();
}

function nextSlide() {
  if (currentSlide === 3 && !candlesBlown) {
    const micStatus = document.getElementById("mic-status");
    if (micStatus) {
      micStatus.innerText = "💨 Blow out the candles using the mic to continue!";
    }
    return;
  }
  if (currentSlide < totalSlides) {
    showSlide(currentSlide + 1);
  }
}

function prevSlide() {
  if (currentSlide > 1) {
    showSlide(currentSlide - 1);
  }
}

function playBgMusic() {
  const { bgMusic } = getAudioElements();
  if (!bgMusic) return;

  bgMusic.loop = true;
  bgMusic.muted = false;
  bgMusic.volume = 1.0;

  const playPromise = bgMusic.play();
  if (playPromise !== undefined) {
    playPromise
      .then(() => {
        bgMusicWasActive = true;
      })
      .catch((err) => {
        console.warn("Autoplay gesture blocked, waiting for touch:", err);
        const unlockAudio = () => {
          bgMusic.play().then(() => {
            bgMusicWasActive = true;
            document.removeEventListener("touchstart", unlockAudio);
            document.removeEventListener("click", unlockAudio);
          }).catch(() => {});
        };
        document.addEventListener("touchstart", unlockAudio, { once: true });
        document.addEventListener("click", unlockAudio, { once: true });
      });
  }
}

function pauseBgMusicForVoice() {
  const { bgMusic } = getAudioElements();
  if (bgMusic && !bgMusic.paused) {
    bgMusicWasActive = true;
    bgMusic.pause();
  }
}

function resumeBgMusic() {
  const { bgMusic } = getAudioElements();
  if (bgMusic && bgMusicWasActive) {
    bgMusic.play().catch((err) => {
      console.warn("Could not resume bg music:", err);
    });
  }
}

function openEnvelope() {
  playBgMusic();

  const envelope = document.getElementById("envelope");
  if (envelope) envelope.classList.add("opening");

  if (typeof confetti === "function") {
    confetti({ particleCount: 50, spread: 60, origin: { y: 0.6 } });
  }

  setTimeout(() => {
    const envelopePage = document.getElementById("envelope-page");
    const cardContainer = document.getElementById("card-container");
    if (envelopePage) envelopePage.classList.remove("active-view");
    if (cardContainer) cardContainer.classList.add("active-view");
    initDots();
    showSlide(1);
  }, 1200);
}

function handleQuizNo() {
  const quizPopup = document.getElementById("quiz-popup");
  if (quizPopup) quizPopup.classList.add("active-modal");
}

function closeQuizPopup() {
  const quizPopup = document.getElementById("quiz-popup");
  if (quizPopup) quizPopup.classList.remove("active-modal");
}

function handleQuizYes() {
  if (typeof confetti === "function") {
    confetti({ particleCount: 60, spread: 70, origin: { y: 0.6 } });
  }
  nextSlide();
}

async function activateMicDetection() {
  const micBtn = document.getElementById("mic-btn");
  const micStatus = document.getElementById("mic-status");

  try {
    micStream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
    if (micBtn) micBtn.style.display = "none";
    if (micStatus) micStatus.innerText = "💨 Blow into your microphone now!";

    audioContext = new (window.AudioContext || window.webkitAudioContext)();
    analyser = audioContext.createAnalyser();
    microphone = audioContext.createMediaStreamSource(micStream);
    microphone.connect(analyser);
    analyser.fftSize = 256;

    const bufferLength = analyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);

    function detectBlow() {
      if (candlesBlown) return;

      analyser.getByteFrequencyData(dataArray);
      let values = 0;
      for (let i = 0; i < bufferLength; i++) {
        values += dataArray[i];
      }
      let average = values / bufferLength;

      if (average > 70) {
        blowOutFlame();
        if (micStream) {
          micStream.getTracks().forEach((track) => track.stop());
        }
        return;
      }

      requestAnimationFrame(detectBlow);
    }

    detectBlow();
  } catch (err) {
    console.error("Mic access failed:", err);
    if (micStatus) {
      micStatus.innerText = "⚠️ Microphone permission is required to blow out the candles!";
    }
  }
}

function blowOutFlame() {
  if (candlesBlown) return;
  candlesBlown = true;

  document.querySelectorAll(".flame").forEach((flame) => {
    flame.classList.add("blown-out");
  });

  const micStatus = document.getElementById("mic-status");
  if (micStatus) micStatus.innerText = "✨ The candles are blown out! ✨";

  const bdayMsg = document.getElementById("birthday-message");
  if (bdayMsg) bdayMsg.classList.add("show");

  updateNavButtons();

  if (typeof confetti === "function") {
    confetti({ particleCount: 100, spread: 80, origin: { y: 0.6 } });
  }

  setTimeout(() => {
    const wishPopup = document.getElementById("wish-popup");
    if (wishPopup) wishPopup.classList.add("active-modal");
  }, 1600);
}

function closeWishPopupAndContinue() {
  const wishPopup = document.getElementById("wish-popup");
  if (wishPopup) wishPopup.classList.remove("active-modal");
  nextSlide();
}

function revealGift(element, nickname) {
  if (element.classList.contains("opened")) return;

  element.classList.add("opened");
  const textContainer = element.querySelector(".revealed-nickname");
  if (textContainer) textContainer.innerText = nickname;

  if (typeof confetti === "function") {
    confetti({ particleCount: 30, spread: 50, origin: { y: 0.7 } });
  }
}

function triggerFireworks() {
  if (typeof confetti !== "function") return;

  const duration = 3 * 1000;
  const animationEnd = Date.now() + duration;

  const interval = setInterval(function () {
    const timeLeft = animationEnd - Date.now();
    if (timeLeft <= 0) return clearInterval(interval);

    confetti({
      particleCount: 40,
      startVelocity: 30,
      spread: 360,
      origin: {
        x: Math.random(),
        y: Math.random() - 0.2
      }
    });
  }, 250);
}

document.addEventListener("DOMContentLoaded", () => {
  initDots();
  updateNavButtons();

  const envelope = document.getElementById("envelope");
  if (envelope) {
    envelope.addEventListener("click", openEnvelope);
  }

  const cakeContainer = document.querySelector(".cake-container");
  if (cakeContainer) {
    cakeContainer.removeAttribute("onclick");
    cakeContainer.style.cursor = "default";
  }

  const { voiceNote, voiceBtn } = getAudioElements();

  if (voiceBtn && voiceNote) {
    voiceBtn.addEventListener("click", () => {
      if (voiceNote.paused) {
        pauseBgMusicForVoice();
        voiceNote.play().then(() => {
          voiceBtn.textContent = "⏸ Pause Voice Note";
        }).catch((err) => {
          console.warn("Voice note play error:", err);
          resumeBgMusic();
        });
      } else {
        voiceNote.pause();
      }
    });

    voiceNote.addEventListener("pause", () => {
      voiceBtn.textContent = "▶ Play Voice Note";
      if (!voiceNote.ended) {
        resumeBgMusic();
      }
    });

    voiceNote.addEventListener("ended", () => {
      voiceBtn.textContent = "▶ Play Voice Note";
      resumeBgMusic();
    });
  }
});
